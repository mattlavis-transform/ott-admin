---
title: Extension system
---
# Extension system

The extension system information should go here before it's adopted into GOVUK.
